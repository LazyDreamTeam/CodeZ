##############
## A PROPOS ##
##############

Programme : CodeZ
Version : V1.2
Distribution : Alpha
Auteur :  
- Valentin CARRUESCO aka Idleman (idleman@idleman.fr)
- Yosko
- Akaiken

Langage : - C++
Plugins : - librairie QT
Date : - 10-09-2012

#########
## FAQ ##
#########

Pour toutes questions, merci de vous r�f�rer � idleman@idleman.fr

#############
## LICENCE ##
#############

Ce programme est sous licence CC by nc. Merci de respecter la licence du logiciel et de la librairie QT int�gr�.

